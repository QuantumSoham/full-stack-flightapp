package com.flightapp.apigateway.model;

public enum UserRole {
    ROLE_USER,
    ROLE_ADMIN
}
